package com.company.professions;

public class Person {
    // Реализация класса Person на ваше усмотрение
}